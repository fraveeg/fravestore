const products = [
  {
    name: "Car Poster",
    price: 150,
    image: "images/car.jpg"
  },
  {
    name: "Luxury Poster",
    price: 200,
    image: "images/luxury.jpg"
  },
  {
    name: "Speed Poster",
    price: 180,
    image: "images/speed.jpg"
  }
];

const container = document.getElementById("productsContainer");
const basketItemsContainer = document.getElementById("basketItems");
const totalPriceElement = document.getElementById("totalPrice");
let basket = [];

products.forEach((product, index) => {
  const div = document.createElement("div");
  div.classList.add("product");
  div.innerHTML = `
    <img src="${product.image}" class="product-img" alt="${product.name}">
    <h3 class="product-name">${product.name}</h3>
    <span class="price">${product.price} L.E</span>
    <label class="quantity-label">Quantity</label>
    <input type="number" min="1" value="1" class="quantity-input" id="qty-${index}" />
    <button class="add-btn" onclick="addToBasket(${index})">Add to Basket</button>
  `;
  container.appendChild(div);
});

function addToBasket(index) {
  const qty = parseInt(document.getElementById(`qty-${index}`).value);
  const product = products[index];

  for (let i = 0; i < qty; i++) {
    basket.push(product);
  }

  updateBasket();
}

function updateBasket() {
  basketItemsContainer.innerHTML = "";
  if (basket.length === 0) {
    basketItemsContainer.innerHTML = "<p>Your basket is empty.</p>";
    totalPriceElement.innerText = "Total: 0 L.E";
    return;
  }

  const grouped = {};
  basket.forEach(p => {
    const key = p.name;
    if (!grouped[key]) {
      grouped[key] = { ...p, quantity: 0 };
    }
    grouped[key].quantity++;
  });

  let total = 0;
  for (const key in grouped) {
    const item = grouped[key];
    total += item.price * item.quantity;
    const itemEl = document.createElement("div");
    itemEl.classList.add("basket-item-details");
    itemEl.innerHTML = `
      <img src="${item.image}" class="basket-img" alt="${item.name}" />
      <div>
        <strong>${item.name}</strong><br>
        Qty: ${item.quantity}<br>
        ${item.price * item.quantity} L.E
      </div>
    `;
    basketItemsContainer.appendChild(itemEl);
  }

  totalPriceElement.innerText = `Total: ${total} L.E`;
}
